#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
飞书文档自动更新脚本
用于自动将血常规检查记录更新到飞书文档
"""

import json
import requests
from datetime import datetime
from typing import Dict, List, Optional

class FeishuDocUpdater:
    """飞书文档更新器"""
    
    def __init__(self, app_id: str, app_secret: str, document_token: str):
        self.app_id = app_id
        self.app_secret = app_secret
        self.document_token = document_token
        self.access_token = None
        self.base_url = "https://open.feishu.cn/open-apis"
        
    def get_tenant_access_token(self) -> str:
        """获取tenant_access_token"""
        url = f"{self.base_url}/auth/v3/tenant_access_token/internal"
        
        headers = {
            "Content-Type": "application/json"
        }
        
        data = {
            "app_id": self.app_id,
            "app_secret": self.app_secret
        }
        
        try:
            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()
            result = response.json()
            
            if result.get("code") == 0:
                self.access_token = result.get("tenant_access_token")
                return self.access_token
            else:
                raise Exception(f"获取token失败: {result.get('msg')}")
                
        except Exception as e:
            print(f"❌ 获取access token失败: {e}")
            raise
    
    def get_document_content(self) -> Dict:
        """获取文档内容"""
        if not self.access_token:
            self.get_tenant_access_token()
        
        url = f"{self.base_url}/docx/v1/documents/{self.document_token}/blocks"
        
        headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json"
        }
        
        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            result = response.json()
            
            if result.get("code") == 0:
                return result.get("data", {})
            else:
                raise Exception(f"获取文档内容失败: {result.get('msg')}")
                
        except Exception as e:
            print(f"❌ 获取文档内容失败: {e}")
            raise
    
    def append_to_document(self, content: str) -> bool:
        """向文档追加内容"""
        if not self.access_token:
            self.get_tenant_access_token()
        
        # 首先获取文档结构,找到最后一个block
        url = f"{self.base_url}/docx/v1/documents/{self.document_token}/blocks"
        
        headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json"
        }
        
        try:
            # 获取文档blocks
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            result = response.json()
            
            if result.get("code") != 0:
                raise Exception(f"获取文档结构失败: {result.get('msg')}")
            
            # 找到最后一个block
            blocks = result.get("data", {}).get("items", [])
            if not blocks:
                raise Exception("文档没有找到任何block")
            
            last_block = blocks[-1]
            last_block_id = last_block.get("block_id")
            
            # 在最后一个block后插入新内容
            insert_url = f"{self.base_url}/docx/v1/documents/{self.document_token}/blocks/{last_block_id}/children/batch_insert"
            
            # 创建新block
            new_blocks = [
                {
                    "block_type": 2,  # text block
                    "text": {
                        "elements": [
                            {
                                "text_run": {
                                    "content": content
                                }
                            }
                        ],
                        "style": {
                            "align": 1  # left align
                        }
                    }
                }
            ]
            
            insert_data = {
                "children": new_blocks,
                "index": 0
            }
            
            insert_response = requests.post(insert_url, headers=headers, json=insert_data)
            insert_response.raise_for_status()
            insert_result = insert_response.json()
            
            if insert_result.get("code") == 0:
                print(f"✅ 成功追加内容到文档")
                return True
            else:
                raise Exception(f"插入内容失败: {insert_result.get('msg')}")
                
        except Exception as e:
            print(f"❌ 追加内容失败: {e}")
            raise
    
    def format_blood_test_record(self, record_data: Dict) -> str:
        """
        格式化血常规检查记录为飞书文档格式
        
        Args:
            record_data: 包含检查数据的字典
            
        Returns:
            格式化后的文本内容
        """
        # 这里实现格式化逻辑
        # 根据您的文档格式,将数据转换为飞书文档格式
        pass


def main():
    """测试脚本"""
    # 配置信息
    APP_ID = "cli_a943a2105938dcb1"
    APP_SECRET = "q2ORjIaAaj7Dml93TbT9shpkLLFWAX8I"
    DOCUMENT_TOKEN = "SdszwBkkFizamtkhysOcDyuDnxf"
    
    # 创建更新器
    updater = FeishuDocUpdater(APP_ID, APP_SECRET, DOCUMENT_TOKEN)
    
    # 测试获取token
    try:
        token = updater.get_tenant_access_token()
        print(f"✅ 成功获取access token: {token[:20]}...")
        
        # 测试获取文档内容
        doc_content = updater.get_document_content()
        print(f"✅ 成功获取文档内容")
        
    except Exception as e:
        print(f"❌ 测试失败: {e}")


if __name__ == "__main__":
    main()
