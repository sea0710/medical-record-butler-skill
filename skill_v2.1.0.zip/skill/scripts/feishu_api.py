#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
飞书文档自动更新模块 - 配置独立版
每个用户使用自己的飞书应用和文档
"""

import json
import urllib.request
import urllib.error
import os
from datetime import datetime

# 配置文件路径（用户独立配置）
CONFIG_FILE = os.path.expanduser("~/.chemo-blood-monitor/config.json")

def load_config():
    """加载用户配置"""
    if not os.path.exists(CONFIG_FILE):
        print(f"""
❌ 未找到配置文件！

请先配置您的飞书应用：
1. 运行配置脚本: python3 scripts/setup_config.py
2. 或手动创建配置文件: {CONFIG_FILE}

配置文件格式:
{{
    "app_id": "您的飞书应用ID",
    "app_secret": "您的飞书应用密钥",
    "document_id": "您的飞书文档ID"
}}

详细步骤请参考: docs/飞书配置指南.md
""")
        return None
    
    try:
        with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"❌ 配置文件读取失败: {e}")
        return None


class FeishuAutoUpdater:
    """飞书文档自动更新器"""

    def __init__(self):
        self.token = None
        self.config = load_config()
        
        if self.config:
            self.app_id = self.config.get('app_id')
            self.app_secret = self.config.get('app_secret')
            self.document_id = self.config.get('document_id')
        else:
            self.app_id = None
            self.app_secret = None
            self.document_id = None

    def authenticate(self):
        """获取飞书访问令牌"""
        if not self.app_id or not self.app_secret:
            print("❌ 飞书应用未配置，请先运行配置脚本")
            return False
        
        url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
        
        data = {
            "app_id": self.app_id,
            "app_secret": self.app_secret
        }
        
        headers = {
            "Content-Type": "application/json"
        }
        
        try:
            req = urllib.request.Request(
                url,
                data=json.dumps(data).encode('utf-8'),
                headers=headers,
                method='POST'
            )
            
            with urllib.request.urlopen(req) as response:
                result = json.loads(response.read().decode('utf-8'))
                
                if result.get('code') == 0:
                    self.token = result.get('tenant_access_token')
                    return True
                else:
                    print(f"❌ 认证失败: {result.get('msg')}")
                    return False
        except Exception as e:
            print(f"❌ 认证异常: {e}")
            return False

    def _format_report_as_text(self, report_data):
        """格式化报告为文本"""
        lines = []
        
        # 标题
        lines.append(f"━━━ {report_data.get('date', '未知日期')} 血常规检查 ━━━")
        lines.append("")
        
        # 基本信息
        if report_data.get('hospital'):
            lines.append(f"医院: {report_data['hospital']}")
        if report_data.get('patient'):
            lines.append(f"患者: {report_data['patient']}")
        lines.append("")
        
        # 核心指标
        lines.append("【核心指标】")
        for indicator in report_data.get('indicators', []):
            name = indicator.get('name', '')
            value = indicator.get('value', '')
            unit = indicator.get('unit', '')
            level = indicator.get('level', '')
            status = indicator.get('status', '')
            
            status_emoji = '✅' if '正常' in status else '⚠️'
            lines.append(f"{status_emoji} {name}: {value} {unit} - {level} {status}")
        
        lines.append("")
        
        # 异常总结
        if report_data.get('abnormal_summary'):
            lines.append("【异常项】")
            lines.append(report_data['abnormal_summary'])
            lines.append("")
        
        # 分析
        if report_data.get('analysis'):
            lines.append("【临床分析】")
            lines.append(report_data['analysis'])
            lines.append("")
        
        # 建议
        if report_data.get('recommendations'):
            lines.append("【处理建议】")
            lines.append(report_data['recommendations'])
            lines.append("")
        
        lines.append("━━━━━━━━━━━━━━━━━━━━")
        lines.append("")
        
        return '\n'.join(lines)

    def update_document(self, report_data):
        """更新飞书文档"""
        if not self.document_id:
            print("❌ 文档ID未配置，请先运行配置脚本")
            return False
        
        if not self.token:
            if not self.authenticate():
                return False
        
        # 构建文档内容
        content_text = self._format_report_as_text(report_data)
        
        # 调用飞书API添加内容
        url = f"https://open.feishu.cn/open-apis/docx/v1/documents/{self.document_id}/blocks/{self.document_id}/children"
        
        data = [
            {
                "block_type": 2,  # text block
                "text": {
                    "elements": [
                        {
                            "text_run": {
                                "content": content_text
                            }
                        }
                    ]
                }
            }
        ]
        
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }
        
        try:
            req = urllib.request.Request(
                url,
                data=json.dumps(data).encode('utf-8'),
                headers=headers,
                method='POST'
            )
            
            with urllib.request.urlopen(req) as response:
                result = json.loads(response.read().decode('utf-8'))
                
                if result.get('code') == 0:
                    print(f"✅ 已自动更新到飞书文档: https://feishu.cn/docx/{self.document_id}")
                    return True
                else:
                    print(f"❌ 更新失败: {result.get('msg')}")
                    return False
        except urllib.error.HTTPError as e:
            error_body = e.read().decode('utf-8')
            print(f"❌ HTTP错误: {e.code}")
            print(f"响应: {error_body}")
            return False
        except Exception as e:
            print(f"❌ 更新异常: {e}")
            return False


def auto_update_feishu_document(report_data):
    """自动更新飞书文档的便捷函数"""
    updater = FeishuAutoUpdater()
    return updater.update_document(report_data)


if __name__ == "__main__":
    # 测试代码
    test_report = {
        'date': '2026-03-29',
        'hospital': '测试医院',
        'patient': '测试患者',
        'indicators': [
            {'name': '白细胞(WBC)', 'value': '7.5', 'unit': '×10⁹/L', 'level': '0级', 'status': '正常'}
        ],
        'abnormal_summary': '无异常',
        'analysis': '血常规指标正常',
        'recommendations': '继续监测'
    }
    
    print("测试飞书文档更新...")
    success = auto_update_feishu_document(test_report)
    if success:
        print("测试成功！")
    else:
        print("测试失败，请检查配置")
