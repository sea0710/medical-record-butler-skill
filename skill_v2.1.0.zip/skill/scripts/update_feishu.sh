#!/bin/bash
# 飞书文档自动更新脚本

APP_ID="cli_a943a2105938dcb1"
APP_SECRET="q2ORjIaAaj7Dml93TbT9shpkLLFWAX8I"
DOCUMENT_TOKEN="SdszwBkkFizamtkhysOcDyuDnxf"

# 获取tenant_access_token
echo "正在获取access token..."
TOKEN_RESPONSE=$(curl -s -X POST "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal" \
  -H "Content-Type: application/json" \
  -d "{
    \"app_id\": \"$APP_ID\",
    \"app_secret\": \"$APP_SECRET\"
  }")

echo "Token响应: $TOKEN_RESPONSE"

# 提取token
ACCESS_TOKEN=$(echo $TOKEN_RESPONSE | grep -o '"tenant_access_token":"[^"]*"' | sed 's/"tenant_access_token":"//;s/"//')

if [ -z "$ACCESS_TOKEN" ]; then
  echo "❌ 获取access token失败"
  exit 1
fi

echo "✅ 成功获取access token: ${ACCESS_TOKEN:0:20}..."

# 获取文档blocks
echo "正在获取文档结构..."
BLOCKS_RESPONSE=$(curl -s -X GET "https://open.feishu.cn/open-apis/docx/v1/documents/$DOCUMENT_TOKEN/blocks" \
  -H "Authorization: Bearer $ACCESS_TOKEN")

echo "Blocks响应前200字符: ${BLOCKS_RESPONSE:0:200}"

# 检查是否有权限
CODE=$(echo $BLOCKS_RESPONSE | grep -o '"code":[0-9]*' | sed 's/"code"://')

if [ "$CODE" != "0" ]; then
  echo "❌ 获取文档失败,错误码: $CODE"
  echo "完整响应: $BLOCKS_RESPONSE"
  exit 1
fi

echo "✅ 成功连接飞书API并获取文档结构"
