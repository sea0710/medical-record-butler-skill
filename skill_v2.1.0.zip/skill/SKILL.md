---
name: chemo-blood-monitor
description: This skill should be used when users need to analyze chemotherapy blood test reports, identify abnormal indicators, provide handling recommendations, and track historical data. Triggered when users upload blood test report images or ask questions about blood test indicators after chemotherapy.
---

# Chemo Blood Monitor

## Overview

This skill helps cancer patients and their families monitor blood test indicators after chemotherapy, identify abnormal values, and provide evidence-based handling recommendations. It uses a comprehensive reference document as the sole authority for judging abnormalities and determining appropriate responses.

## When to Use This Skill

Use this skill when:
- Users upload blood test report images (photos or scans)
- Users ask about blood test results and their meanings
- Users need to track changes in blood test indicators over time
- Users request handling advice for abnormal indicators
- Users mention "blood test", "blood routine", "chemotherapy", or specific indicator names

## Core Workflow

### Step 1: Receive and Analyze Blood Test Report Image

When a user sends a blood test report image:

1. **Extract Key Information**:
   - Examination date
   - Hospital/Lab name (if visible)
   - Patient information (if visible, keep confidential)
   - All blood test indicators and their values
   - Reference ranges shown on the report

2. **Focus on Core Indicators**:
   - 白细胞 (WBC) - White Blood Cell count
   - 中性粒细胞 (ANC) - Absolute Neutrophil Count
   - 血小板 (PLT) - Platelet count
   - 血红蛋白 (Hb) - Hemoglobin
   - Other relevant indicators if present

3. **Data Extraction Best Practices**:
   - Use vision capabilities to accurately read numbers
   - Note the units (usually ×10⁹/L for WBC/ANC/PLT, g/L for Hb)
   - If image is unclear or numbers are ambiguous, explicitly state this
   - Do NOT guess or fabricate data

### Step 2: Evaluate Abnormalities Using Reference Document

Use the reference document `references/blood_test_reference.json` as the **sole authority** for judging abnormalities.

For each indicator:

1. **Determine the Level**:
   - 0级 (Grade 0): Normal
   - I级 (Grade I): Mild abnormality
   - II级 (Grade II): Moderate abnormality
   - III级 (Grade III): Severe abnormality
   - IV级 (Grade IV): Very severe abnormality

2. **Special Considerations**:
   - For Hemoglobin (Hb): Check patient gender if available
     - Male normal: ≥120 g/L
     - Female normal: ≥110 g/L
   - For ANC: Critical threshold is <0.5×10⁹/L (infection risk)
   - For PLT: Critical threshold is <20×10⁹/L (bleeding crisis)
   - For WBC: Check both WBC and ANC together

3. **Priority Assessment**:
   - IV级: Immediate medical attention required
   - III级: Urgent medical attention needed
   - II级: Medical consultation recommended
   - I级: Observation and monitoring

### Step 3: Generate Comprehensive Report

Create a detailed report with the following structure:

#### 3.1 Examination Date
Display the examination date prominently.

#### 3.2 Indicator Analysis Table

Create a clear table showing all indicators:

```
| 指标名称 | 检测值 | 单位 | 正常范围 | 异常级别 | 状态 |
|---------|-------|------|---------|---------|------|
| [Name] | [Value] | [Unit] | [Range] | [Level] | [Status] |
```

**Status Indicators**:
- ✅ Normal
- ⚠️ Mild abnormality
- 🔴 Moderate abnormality
- 🚨 Severe abnormality - requires immediate attention

#### 3.3 Abnormal Indicators Summary

List all abnormal indicators with:
- Indicator name and value
- Severity level
- Brief clinical significance
- Priority ranking (IV级 > III级 > II级 > I级)

#### 3.4 Handling Recommendations

For each abnormal indicator, provide:

1. **Treatment Principles**:
   - From the reference document's "处理原则" field
   - Specific to the abnormality level

2. **Discharge Orders** (if applicable):
   - From the reference document's "出院医嘱" field
   - Include medication names, dosages, and frequencies
   - Note follow-up requirements

3. **Self-Monitoring Guidance**:
   - From the reference document's "自我监测" field
   - Specific symptoms to watch for
   - Temperature monitoring instructions
   - Warning signs requiring immediate medical attention

4. **Life Care Instructions**:
   - From the reference document's "生活护理" field
   - Daily activity modifications
   - Dietary recommendations
   - Environmental precautions

#### 3.5 Next Steps and Action Items

Provide clear, actionable guidance:

- **Immediate Actions**: If IV级 or III级 abnormalities exist
- **Follow-up Schedule**: When to retest
- **Medication Guidance**: If medications are needed
- **Emergency Warning Signs**: When to seek immediate medical care

### Step 4: Automatic Feishu Document Update

**AUTOMATIC UPDATE**: The system will automatically update the Feishu document after analyzing each blood test report. No manual action required from the user.

1. **Feishu Document Information**:
   - Document ID: `TDEKdMYWmoykbCx2jj7cym8vnqf`
   - Document Link: https://feishu.cn/docx/TDEKdMYWmoykbCx2jj7cym8vnqf
   - Title: "化疗血常规监测记录"

2. **Automatic Update Process**:
   After generating the comprehensive report, the system will:
   - Automatically call the Feishu API to append the new record
   - Add the examination data to the document
   - Include all indicators, analysis, and recommendations
   - Maintain historical tracking automatically

3. **Update Script**:
   Use the script at `scripts/feishu_api.py` which:
   - Authenticates with Feishu Open Platform
   - Appends new content to the existing document
   - Handles formatting and structure
   - Returns success/failure status

4. **User Notification**:
   After automatic update, inform the user:
   - ✅ "已自动更新到飞书文档"
   - Provide the document link for viewing
   - No further action needed from the user

## Emergency Warning Signs

**Immediate medical attention required if**:

1. **ANC < 0.5×10⁹/L**: Severe neutropenia, high infection risk
2. **PLT < 20×10⁹/L**: Bleeding crisis, risk of spontaneous hemorrhage
3. **Hb < 60 g/L**: Severe anemia, risk of cardiac complications
4. **Temperature ≥ 38.0℃**: Fever with low ANC = medical emergency
5. **Active bleeding**: Gum bleeding, nosebleeds, blood in stool/urine
6. **Severe symptoms**: Chest pain, difficulty breathing, severe weakness

## Best Practices

### Accuracy and Safety

1. **Never Fabricate Data**:
   - If the image is unclear, explicitly state what cannot be read
   - Ask user to clarify if critical information is missing

2. **Use Only the Reference Document**:
   - All judgments must be based on `references/blood_test_reference.json`
   - Do not use other sources or personal knowledge for clinical thresholds

3. **Prioritize Patient Safety**:
   - Always err on the side of caution
   - When in doubt, recommend medical consultation
   - Emphasize that this skill provides guidance, not medical diagnosis

### Communication Style

1. **Clear and Compassionate**:
   - Use plain language, avoid excessive medical jargon
   - Show empathy for the patient and family's situation
   - Provide reassurance while being honest about concerns

2. **Action-Oriented**:
   - Provide specific, actionable recommendations
   - Include "what to do next" sections
   - Set clear follow-up expectations

3. **Comprehensive but Organized**:
   - Structure information hierarchically (most important first)
   - Use visual indicators (emoji, colors) to draw attention
   - Summarize key points

## Example User Interactions

### Example 1: First-Time User

**User**: [Uploads blood test report image]

**Response**:
1. Extract data from image
2. Evaluate all indicators
3. Generate comprehensive report with table, summary, and recommendations
4. Create initial Feishu tracking document
5. Provide next steps

### Example 2: Follow-Up Check

**User**: "这是今天的检查结果" [Uploads new report]

**Response**:
1. Extract data from new image
2. Evaluate indicators
3. Compare with historical data from Feishu document
4. Highlight trends (improving, stable, worsening)
5. Update Feishu document with new data
6. Provide updated recommendations

### Example 3: Specific Question

**User**: "我的白细胞只有2.5,严重吗?"

**Response**:
1. Confirm understanding (WBC = 2.5×10⁹/L)
2. Check reference document: This is II级 (moderate reduction)
3. Explain clinical significance
4. Provide handling recommendations
5. Suggest follow-up actions

## Resources

### references/blood_test_reference.json

The complete reference document containing:
- Normal ranges and abnormal thresholds for all indicators
- Clinical significance of each indicator
- Handling principles for each level
- Discharge orders and medication guidance
- Self-monitoring instructions
- Life care recommendations

**Usage**: This file is loaded into context when evaluating blood test results. All abnormality judgments and recommendations must be based on this document.

### scripts/

Contains the Feishu API integration script:

**scripts/feishu_api.py** - Automated Feishu document updater:
- Handles authentication with Feishu Open Platform
- Automatically appends new blood test records to the document
- Formats content with proper structure
- No manual intervention required from users

**Usage**: This script is called automatically when a blood test report is analyzed. Users do not need to interact with it directly.

### assets/

Currently empty. Future assets could include:
- Feishu document templates
- Patient education materials
- Emergency contact cards
