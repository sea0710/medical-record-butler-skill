#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
快速配置脚本 - 简化版
帮助用户快速配置自己的飞书应用
"""
import json
import os
import sys

def get_user_input():
    """获取用户输入的配置信息"""
    print("=" * 60)
    print("🚀 化疗血常规监测Skill - 配置向导")
    print("=" * 60)
    print()
    
    print("本脚本将帮助您配置自己的飞书应用和文档")
    print("每个用户使用独立的飞书应用,数据完全隔离")
    print()
    print("📖 如果还没有飞书应用,请先阅读: docs/飞书配置指南.md")
    print()

    # 飞书配置
    print("【飞书应用配置】")
    print("提示: 这些信息可以在飞书开放平台获取")
    print()
    
    app_id = input("1. App ID (格式: cli_xxxxxx): ").strip()
    if not app_id:
        print("❌ App ID 不能为空")
        return None
    
    app_secret = input("2. App Secret: ").strip()
    if not app_secret:
        print("❌ App Secret 不能为空")
        return None
    
    document_id = input("3. 飞书文档ID (从文档URL中提取): ").strip()
    if not document_id:
        print("❌ 文档ID 不能为空")
        return None
    
    print()

    # 确认信息
    print("=" * 60)
    print("📋 配置信息确认:")
    print("=" * 60)
    print(f"App ID:      {app_id}")
    print(f"App Secret:  {'*' * 10}{app_secret[-6:]}")
    print(f"文档ID:      {document_id}")
    print(f"文档链接:    https://feishu.cn/docx/{document_id}")
    print()

    confirm = input("确认以上信息正确? (y/n): ").strip().lower()
    if confirm != 'y':
        print("❌ 配置已取消")
        return None

    # 构建配置对象（简化版）
    config = {
        "app_id": app_id,
        "app_secret": app_secret,
        "document_id": document_id
    }

    return config

def save_config(config):
    """保存配置文件到用户目录"""
    # 使用用户主目录下的隐藏文件夹
    config_dir = os.path.expanduser("~/.chemo-blood-monitor")
    config_path = os.path.join(config_dir, "config.json")
    
    try:
        # 确保目录存在
        os.makedirs(config_dir, exist_ok=True)
        
        # 保存配置
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        
        print(f"\n✅ 配置文件已保存到: {config_path}")
        return True
    except Exception as e:
        print(f"❌ 保存配置失败: {e}")
        return False

def main():
    """主函数"""
    print()
    
    # 获取用户输入
    config = get_user_input()
    if not config:
        sys.exit(1)

    # 保存配置
    if not save_config(config):
        sys.exit(1)

    # 完成
    print("\n" + "=" * 60)
    print("🎉 配置完成!")
    print("=" * 60)
    print()
    print("✅ 您的配置信息:")
    print(f"   - 飞书应用ID: {config['app_id']}")
    print(f"   - 飞书文档: https://feishu.cn/docx/{config['document_id']}")
    print()
    print("📝 下一步:")
    print("   1. 安装 Skill (如果还未安装)")
    print("   2. 发送血常规检查报告图片给 AI")
    print("   3. AI 会自动识别并更新到您的飞书文档")
    print()
    print("🔒 安全提示:")
    print("   - 您的配置存储在本地: ~/.chemo-blood-monitor/config.json")
    print("   - 请勿将 App Secret 分享给他人")
    print("   - 每个用户使用独立的飞书应用,数据完全隔离")
    print()
    print("💡 如需修改配置,可以:")
    print(f"   - 编辑文件: ~/.chemo-blood-monitor/config.json")
    print("   - 或重新运行本脚本")

if __name__ == "__main__":
    main()
