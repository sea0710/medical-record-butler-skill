#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
飞书文档自动更新模块 - 完全自动化
用于化疗血常规监测skill

功能:
- 自动认证并获取访问令牌
- 自动追加血常规检查记录到飞书文档
- 无需用户手动操作
"""
import json
import urllib.request
import urllib.error
import ssl
from datetime import datetime

# 解决SSL证书验证问题
ssl._create_default_https_context = ssl._create_unverified_context

# 飞书应用配置
APP_ID = "cli_a943a2105938dcb1"
APP_SECRET = "q2ORjIaAaj7Dml93TbT9shpkLLFWAX8I"
DOCUMENT_ID = "TDEKdMYWmoykbCx2jj7cym8vnqf"

class FeishuAutoUpdater:
    """飞书文档自动更新器"""
    
    def __init__(self):
        self.token = None
        self.document_id = DOCUMENT_ID
    
    def authenticate(self):
        """获取飞书访问令牌"""
        url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
        
        data = {
            "app_id": APP_ID,
            "app_secret": APP_SECRET
        }
        
        headers = {
            "Content-Type": "application/json"
        }
        
        req = urllib.request.Request(
            url,
            data=json.dumps(data).encode('utf-8'),
            headers=headers,
            method='POST'
        )
        
        try:
            with urllib.request.urlopen(req) as response:
                result = json.loads(response.read().decode('utf-8'))
                if result.get('code') == 0:
                    self.token = result.get('tenant_access_token')
                    return True
                else:
                    print(f"❌ 认证失败: {result}")
                    return False
        except Exception as e:
            print(f"❌ 认证请求失败: {e}")
            return False
    
    def append_blood_test_record(self, report_data):
        """
        追加血常规检查记录到飞书文档
        
        参数:
            report_data: 字典,包含以下字段:
                - date: 检查日期 (格式: YYYY-MM-DD)
                - hospital: 医院名称
                - patient: 患者信息
                - indicators: 指标列表
                - abnormal_summary: 异常项总结
                - analysis: 临床分析
                - recommendations: 处理建议
        
        返回:
            bool: 是否成功更新
        """
        # 确保已认证
        if not self.token:
            if not self.authenticate():
                return False
        
        # 构建文档内容 - 格式化为简单的文本块
        content_text = self._format_report_as_text(report_data)
        
        # 调用飞书API添加内容
        url = f"https://open.feishu.cn/open-apis/docx/v1/documents/{self.document_id}/blocks/{self.document_id}/children"
        
        data = {
            "children": [
                {
                    "block_type": 2,  # text block
                    "text": {
                        "elements": [
                            {
                                "text_run": {
                                    "content": content_text,
                                    "text_element_style": {}
                                }
                            }
                        ]
                    }
                }
            ],
            "index": 0  # 插入到文档开头
        }
        
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }
        
        req = urllib.request.Request(
            url,
            data=json.dumps(data).encode('utf-8'),
            headers=headers,
            method='POST'
        )
        
        try:
            with urllib.request.urlopen(req) as response:
                result = json.loads(response.read().decode('utf-8'))
                if result.get('code') == 0:
                    print(f"✅ 已自动更新到飞书文档: https://feishu.cn/docx/{self.document_id}")
                    return True
                else:
                    print(f"❌ 更新失败: {result}")
                    return False
        except urllib.error.HTTPError as e:
            print(f"❌ HTTP错误: {e.code}")
            print(f"错误详情: {e.read().decode()}")
            return False
        except Exception as e:
            print(f"❌ 请求失败: {e}")
            return False
    
    def _format_report_as_text(self, report_data):
        """将报告格式化为文本"""
        lines = []
        
        # 分隔线
        lines.append("=" * 50)
        
        # 标题
        date_str = report_data.get('date', datetime.now().strftime('%Y-%m-%d'))
        lines.append(f"📅 {date_str} 检查记录")
        lines.append("")
        
        # 基本信息
        hospital = report_data.get('hospital', '未知医院')
        patient = report_data.get('patient', '未知')
        lines.append(f"🏥 医院: {hospital}")
        lines.append(f"👤 患者: {patient}")
        lines.append("")
        
        # 核心指标
        indicators = report_data.get('indicators', [])
        if indicators:
            lines.append("📊 核心指标:")
            for ind in indicators:
                status_emoji = "✅" if ind.get('level') == '0级' else "⚠️" if ind.get('level') == 'I级' else "🔴"
                lines.append(f"{status_emoji} {ind['name']}: {ind['value']} {ind['unit']} ({ind.get('status', '正常')})")
            lines.append("")
        
        # 异常项总结
        abnormal_summary = report_data.get('abnormal_summary', '')
        if abnormal_summary:
            lines.append("⚠️ 异常项总结:")
            lines.append(abnormal_summary)
            lines.append("")
        
        # 临床分析
        analysis = report_data.get('analysis', '')
        if analysis:
            lines.append("🔍 临床分析:")
            lines.append(analysis)
            lines.append("")
        
        # 处理建议
        recommendations = report_data.get('recommendations', '')
        if recommendations:
            lines.append("💡 处理建议:")
            lines.append(recommendations)
            lines.append("")
        
        return "\n".join(lines)


def auto_update_feishu_document(report_data):
    """
    自动更新飞书文档的主函数
    
    这是供外部调用的接口函数
    
    参数:
        report_data: 字典格式的检查报告数据
    
    返回:
        bool: 是否成功更新
    """
    updater = FeishuAutoUpdater()
    return updater.append_blood_test_record(report_data)


# 测试代码
if __name__ == "__main__":
    print("=== 测试飞书文档自动更新 ===\n")
    
    # 模拟一份血常规检查报告数据
    test_report = {
        "date": "2026-03-29",
        "hospital": "北京大学人民医院",
        "patient": "王才, 男, 61岁",
        "indicators": [
            {"name": "白细胞(WBC)", "value": "7.5", "unit": "×10⁹/L", "level": "0级", "status": "正常"},
            {"name": "中性粒细胞(ANC)", "value": "5.2", "unit": "×10⁹/L", "level": "0级", "status": "正常"},
            {"name": "血小板(PLT)", "value": "150", "unit": "×10⁹/L", "level": "0级", "status": "正常"},
            {"name": "血红蛋白(Hb)", "value": "145", "unit": "g/L", "level": "0级", "status": "正常"}
        ],
        "abnormal_summary": "所有核心指标均在正常范围内",
        "analysis": "血常规指标良好,无骨髓抑制表现",
        "recommendations": "继续监测,定期复查血常规"
    }
    
    # 自动更新到飞书
    success = auto_update_feishu_document(test_report)
    
    if success:
        print("\n✅ 测试成功!文档已自动更新")
        print(f"📄 查看文档: https://feishu.cn/docx/{DOCUMENT_ID}")
    else:
        print("\n❌ 测试失败")
